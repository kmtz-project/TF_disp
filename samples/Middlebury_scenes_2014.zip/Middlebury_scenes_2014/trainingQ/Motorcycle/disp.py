from PIL import Image
import cv2

'''file = open("calib.txt",'r')

params = file.read()
print(params)
params = params.split('\n')
max_disp_pos = [i for i in params if i.startswith('ndisp=')]
max_disp = int(max_disp_pos[0][6::])
print(max_disp)
'''

disp_pic = cv2.imread("disp0GT.pfm")
cv2.imwrite("disp0GT.png", disp_pic)


